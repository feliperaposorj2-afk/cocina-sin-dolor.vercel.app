# Cocina Sin Dolor — página de vendas (fibromialgia, LATAM)

Página de vendas em **espanhol** para o público da América Latina: receitas naturais antiinflamatórias para fibromialgia.
Site estático: um único `index.html` (HTML + CSS + JS no mesmo arquivo), sem build e sem dependências.

## Arquivos
- `index.html` — a página inteira
- `especialista.webp` — foto da especialista (bloco "Hola, soy Lucía Morales")
- `mockup.webp` — imagem do produto no topo (hero)
- `.claude/launch.json` — servidor local para o preview do Claude

## Rodar em localhost
No Claude Code: abrir o preview `cocina-sin-dolor` (usa `.claude/launch.json`) → http://localhost:3095
No terminal, dentro desta pasta:
    python -m http.server 3095
e abrir http://localhost:3095
(sem Python: `npx serve -l 3095 .`)

## Estrutura da página (na ordem)
barra com contador → hero (headline + mockup) → dores → método em 3 passos → entregável (6 módulos, 120 receitas)
→ 4 bônus → especialista → 5 depoimentos → 2 preços (Básico US$ 9,90 / Completo US$ 12) → garantia 7 dias → FAQ → CTA final → rodapé com aviso médico.
Ao clicar no plano Básico abre um popup oferecendo o Completo por mais US$ 2,10.

## Onde mexer
- Cores e fontes: variáveis em `:root` no topo do `<style>`.
- Links de checkout: constantes `CHECKOUT_BASICO` e `CHECKOUT_COMPLETO` no `<script>` no fim do arquivo (hoje são placeholders). Os parâmetros UTM da URL são repassados ao checkout automaticamente.
- Headline: `<h1>` dentro de `<header class="hero">`.

## Pendências conhecidas
- Checkout ainda sem link real.
- Especialista e depoimentos são fictícios (exemplo) — trocar por reais antes de anunciar.
- `mockup.webp` tem textos em português ("Vida Sem Dor"); ideal refazer em espanhol com o nome do produto.
- Não prometer cura da fibromialgia (política da Meta); usar "aliviar", "reducir la inflamación".
